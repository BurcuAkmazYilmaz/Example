﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ReceiptScanner
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region json'dan model oluşturma

            List<ReceiptModel> items = new List<ReceiptModel>();

            using (StreamReader r = new StreamReader("response.json"))
            {
                string strResponsejson = r.ReadToEnd();

                items = JsonConvert.DeserializeObject<List<ReceiptModel>>(strResponsejson);
            }

            List<ResultModel> lstResultModel = new List<ResultModel>();

            for (int i = 1; i < items.Count; i++)
            {
                ResultModel resultModel = new ResultModel();

                resultModel.description = items[i].description;
                resultModel.locale = items[i].locale;

                resultModel.x1 = items[i].boundingPoly.vertices[0].x;
                resultModel.y1 = items[i].boundingPoly.vertices[0].y;

                resultModel.x2 = items[i].boundingPoly.vertices[1].x;
                resultModel.y2 = items[i].boundingPoly.vertices[1].y;

                resultModel.x3 = items[i].boundingPoly.vertices[2].x;
                resultModel.y3 = items[i].boundingPoly.vertices[2].y;

                resultModel.x4 = items[i].boundingPoly.vertices[3].x;
                resultModel.y4 = items[i].boundingPoly.vertices[3].y;

                lstResultModel.Add(resultModel);
            } 

            #endregion

            #region Sıralama - satır bazlı sıralama yapmak için y1 değerlerine göre sıralama yapılır.

            List<ResultModel> lstResultModel_sirali = (from r in lstResultModel
                                                       orderby r.y1
                                                       select r).ToList();

            ResultModel flagResultModel1 = new ResultModel();

            for (int i = 0; i < lstResultModel_sirali.Count() - 1; i++)
            {
                for (int j = i; j < lstResultModel_sirali.Count(); j++)
                {
                    if (lstResultModel_sirali[i].x1 > lstResultModel_sirali[j].x1 && (lstResultModel_sirali[i].y1 + 10) > lstResultModel_sirali[j].y1)
                    {
                        flagResultModel1 = lstResultModel_sirali[j];

                        lstResultModel_sirali[j] = lstResultModel_sirali[i];
                        lstResultModel_sirali[i] = flagResultModel1;
                    }
                }
            } 

            #endregion

            StringBuilder stringBuilder = new StringBuilder();

            for (int i = 0; i < lstResultModel_sirali.Count(); i++)
            {
                string strDescription = lstResultModel_sirali[i].description;

                if (i + 1 < lstResultModel_sirali.Count())
                {
                    int x2 = lstResultModel_sirali[i].x2;
                    int y2 = lstResultModel_sirali[i].y2;
                    int y4 = lstResultModel_sirali[i].y4;

                    int x1Sonraki = lstResultModel_sirali[i + 1].x1;
                    int y1Sonraki = lstResultModel_sirali[i + 1].y1;

                    if (x2 <= x1Sonraki)
                    {
                        stringBuilder.Append(strDescription);
                        stringBuilder.Append(" ");
                    }
                    else if (x2 > x1Sonraki && (y4 <= y1Sonraki))
                    {

                        stringBuilder.AppendLine(strDescription);
                    }
                    else
                    {
                        stringBuilder.Append(strDescription);
                        stringBuilder.Append(" ");
                    }
                }
                else
                {
                    stringBuilder.AppendLine(strDescription);
                }
            }

            Console.WriteLine(stringBuilder.ToString());

            Console.ReadLine();

        }
    }
}
