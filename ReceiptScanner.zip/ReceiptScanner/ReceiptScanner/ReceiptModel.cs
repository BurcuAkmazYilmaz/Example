﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReceiptScanner
{
    internal class ReceiptModel
    {
        public string locale { get; set; }
        public string description { get; set; }
        public BoundingPolyModel boundingPoly { get; set; }
    }

    internal class BoundingPolyModel
    {
        public List<VerticesModel> vertices { get; set; }
    }

    internal class VerticesModel
    {
        public int x { get; set; }
        public int y { get; set; }
    }

    internal class ResultModel
    {
        public string locale { get; set; }
        public string description { get; set; }
        public int x1 { get; set; }
        public int y1 { get; set; }
        public int x2 { get; set; }
        public int y2 { get; set; }
        public int x3 { get; set; }
        public int y3 { get; set; }
        public int x4 { get; set; }
        public int y4 { get; set; }
    }
    
}
