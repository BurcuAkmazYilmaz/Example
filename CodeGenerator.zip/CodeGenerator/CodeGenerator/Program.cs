﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeGenerator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 10.000.000 adet kod üretilecektir.
            // Kodlar 8 hane uzunluğunda ve unique olmalıdır.
            // Kodlar ACDEFGHKLMNPRTXYZ234579 karakter kümesini içermelidir.
            // Kolayca tahmin edilememesi için ardışık sıralı üretim yapılmamalıdır. 


            //  List<string> lstCharacterNumber = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };

            Console.WriteLine("**************************************");
            Console.WriteLine("ORNEK KODLAR ICIN GECERLILIK KONTROLU");
            Console.WriteLine("**************************************");

            // Her bir harf veya rakam için tutulan kullanılabilecek karakter listesi
            Dictionary<string, List<string>> dicAllow = GetAllowedDictionary();

            List<string> lstCharacterNumber = new List<string>() { "ACEGDMHX", "2", "AC", "ACE", "BCE012JC", "ACEGDMHXACEGDMHX" };

            foreach (var item in lstCharacterNumber)
            {
                bool bCheck = CheckCode(item, dicAllow);

                if (bCheck)
                {
                    Console.WriteLine(string.Format("{0} --> Kod geçerli. ", item));
                }
                else
                {
                    Console.WriteLine(string.Format("{0} --> Kod geçersiz! ", item));
                }
            }

            Console.WriteLine("**************************************");

            Console.WriteLine("**************************************");
            Console.WriteLine("URETILEN TEMSILI 1000 KOD");
            Console.WriteLine("**************************************");

            for (int i = 0; i < 1000; i++)
            {
                string strResult = GenerateCodes(dicAllow);

                if (string.IsNullOrEmpty(strResult) == false)
                {
                    Console.WriteLine(strResult);
                }
                else
                {
                    Console.WriteLine("Mukerrer kayit uretildi!");
                }
            }

            Console.WriteLine("**************************************");

            Console.ReadLine();
        }

        private static int index1 = 0;
        private static int index2 = 0;
        private static int index3 = 0;
        private static int index4 = 0;
        private static int index5 = 0;
        private static int index6 = 0;
        private static int index7 = 0;
        private static int index8 = 0;

        private static int count1 = 0;
        private static int count2 = 0;
        private static int count3 = 0;
        private static int count4 = 0;
        private static int count5 = 0;
        private static int count6 = 0;
        private static int count7 = 0;
        private static int count8 = 0;

        /// <summary>
        /// 8 karakterli kod üretir.
        /// </summary>
        /// <param name="dic">Her bir harf veya rakam için kullanılabilecek karakter listesi</param>
        /// <returns></returns>
        private static string GenerateCodes(Dictionary<string, List<string>> dic)
        {
            string strResult = null;
            //int iValueLength = 8;

            List<string> lstCharacterNumber = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };

            #region 8 basamaklı kod oluşturulurken her bir basamak için ayrı ayrı değer üretilir.

            StringBuilder sbResult = new StringBuilder();

            // Karakterlerden ilki seçilir.
            string c1 = lstCharacterNumber[index1]; // A
            sbResult.Append(c1);

            string c2 = RandomChar(dic, c1, sbResult.ToString(), ref index2, ref count1);
            if (string.IsNullOrEmpty(c2) == false)
                sbResult.Append(c2);
            else
                Console.WriteLine("Deger null.");

            string c3 = RandomChar(dic, c2, sbResult.ToString(), ref index3, ref count2);
            if (string.IsNullOrEmpty(c3) == false)
                sbResult.Append(c3);
            else
                Console.WriteLine("Deger null.");

            string c4 = RandomChar(dic, c3, sbResult.ToString(), ref index4, ref count3);
            if (string.IsNullOrEmpty(c4) == false)
                sbResult.Append(c4);
            else
                Console.WriteLine("Deger null.");

            string c5 = RandomChar(dic, c4, sbResult.ToString(), ref index5, ref count4);
            if (string.IsNullOrEmpty(c5) == false)
                sbResult.Append(c5);
            else
                Console.WriteLine("Deger null.");

            string c6 = RandomChar(dic, c5, sbResult.ToString(), ref index6, ref count5);
            if (string.IsNullOrEmpty(c6) == false)
                sbResult.Append(c6);
            else
                Console.WriteLine("Deger null.");

            string c7 = RandomChar(dic, c6, sbResult.ToString(), ref index7, ref count6);
            if (string.IsNullOrEmpty(c7) == false)
                sbResult.Append(c7);
            else
                Console.WriteLine("Deger null.");

            string c8 = RandomChar(dic, c7, sbResult.ToString(), ref index8, ref count7);
            if (string.IsNullOrEmpty(c8) == false)
                sbResult.Append(c8);
            else
                Console.WriteLine("Deger null.");

            #endregion

            #region Herbir index için değer üretildikten sonra index'ler ayarlanır.

            // 8 karakterli oluşturulan değer için son basamaktan başlanarak sırayla gelebilecek değerler ile yeni kodlar üretilir. 
            // Son basamak için gelebilecek değerler bitince son index sıfırlanarak bir önceki index artırılarak değerler üretilir.

            index8++;

            if (count7 <= index8)
            {
                index8 = 0;
                index7++;
            }

            if (count6 <= index7)
            {
                index7 = 0;
                index8 = 0;
                index6++;
            }

            if (count5 <= index6)
            {
                index6 = 0;
                index7 = 0;
                index8 = 0;
                index5++;
            }

            if (count4 <= index5)
            {
                index5 = 0;
                index6 = 0;
                index7 = 0;
                index8 = 0;
                index4++;
            }

            if (count3 <= index4)
            {
                index4 = 0;
                index5 = 0;
                index6 = 0;
                index7 = 0;
                index8 = 0;
                index3++;
            }

            if (count2 <= index3)
            {
                index3 = 0;
                index4 = 0;
                index5 = 0;
                index6 = 0;
                index7 = 0;
                index8 = 0;
                index2++;
            }

            if (count1 <= index2)
            {
                index2 = 0;
                index3 = 0;
                index4 = 0;
                index5 = 0;
                index6 = 0;
                index7 = 0;
                index8 = 0;
                index1++;
            }

            #endregion

            strResult = sbResult.ToString();

            return strResult;
        }

        /// <summary>
        /// Üretilmiş kodun geçerliliğini kontrol eder.
        /// </summary>
        /// <param name="strCode">Kontrol edilecek kod değeri</param>
        /// <param name="dic">Her bir harf veya rakam için kullanılabilecek karakter listesi</param>
        /// <returns></returns>
        private static bool CheckCode(string strCode, Dictionary<string, List<string>> dic)
        {
            bool bResult = true;

            if (String.IsNullOrEmpty(strCode))
            {
                return false;
            }
            else
            {
                if (strCode.Length != 8)
                {
                    return false;
                }
            }

            // Kod içindeki herbir karaktere bakılarak sonrasında gelen değer, karakter için kullanılabilecek listede yer alıyor mu kontrol edilir.
            for (int i = 0; i < strCode.Length - 1; i++)
            {
                string strKarakter = strCode[i].ToString();
                string strSonrakiKarakter = strCode[i + 1].ToString();

                List<string> lstKarakter = new List<string>();

                if (dic.ContainsKey(strKarakter))
                {
                    dic.TryGetValue(strKarakter, out lstKarakter);
                }

                // Sonraki karakter kullanılabilecek karakter listesinde yok ise kod geçersizdir.
                if (lstKarakter.Contains(strSonrakiKarakter) == false)
                {
                    return false;
                }
            }

            return bResult;
        }

        /// <summary>
        /// Her bir harf veya rakam için kullanılabilecek karakter listesini tutar.
        /// </summary>
        /// <returns></returns>
        private static Dictionary<string, List<string>> GetAllowedDictionary()
        {
            List<string> lstValueA = new List<string>() { "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueC = new List<string>() { "A", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueD = new List<string>() { "A", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueE = new List<string>() { "A", "C", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueF = new List<string>() { "A", "C", "D", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueG = new List<string>() { "A", "C", "D", "E", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueH = new List<string>() { "A", "C", "D", "E", "F", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueK = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "M", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueL = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "N", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueM = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueN = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "P", "R", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueP = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueR = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "T", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueT = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "X", "Y", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueX = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "Z", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueY = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "2", "3", "4", "5", "7", "9" };
            List<string> lstValueZ = new List<string>() { "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "2", "3", "4", "5", "7", "9" };

            List<string> lstValue2 = new List<string>() { "4", "5", "7", "9", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };
            List<string> lstValue3 = new List<string>() { "5", "7", "9", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };
            List<string> lstValue4 = new List<string>() { "2", "7", "9", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };
            List<string> lstValue5 = new List<string>() { "2", "3", "7", "9", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };
            List<string> lstValue7 = new List<string>() { "2", "3", "4", "5", "9", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };
            List<string> lstValue9 = new List<string>() { "2", "3", "4", "5", "7", "A", "C", "D", "E", "F", "G", "H", "K", "L", "M", "N", "P", "R", "T", "X", "Y", "Z" };

            // Her bir harf veya rakam sadece bir defa kullanılır ve ardışık harf ve rakamlar kullanılmaz.
            // Bu yüzden her bir harf veya rakam için kullanılacak karakter listesi tutulur.
            Dictionary<string, List<string>> dicAllow = new Dictionary<string, List<string>>();
            dicAllow.Add("2", lstValue2);
            dicAllow.Add("3", lstValue3);
            dicAllow.Add("4", lstValue4);
            dicAllow.Add("5", lstValue5);
            dicAllow.Add("7", lstValue7);
            dicAllow.Add("9", lstValue9);

            dicAllow.Add("A", lstValueA);
            dicAllow.Add("C", lstValueC);
            dicAllow.Add("D", lstValueD);
            dicAllow.Add("E", lstValueE);
            dicAllow.Add("F", lstValueF);
            dicAllow.Add("G", lstValueG);
            dicAllow.Add("H", lstValueH);
            dicAllow.Add("K", lstValueK);
            dicAllow.Add("L", lstValueL);
            dicAllow.Add("M", lstValueM);
            dicAllow.Add("N", lstValueN);
            dicAllow.Add("P", lstValueP);
            dicAllow.Add("R", lstValueR);
            dicAllow.Add("T", lstValueT);
            dicAllow.Add("X", lstValueX);
            dicAllow.Add("Y", lstValueY);
            dicAllow.Add("Z", lstValueZ);

            return dicAllow;
        }

        /// <summary>
        /// Kullanılabilecek değerler için tutulan dictionary'den yararlanarak her bir basamaktaki karaktere karar veren metot.
        /// Aynı değer önceden kullanılmış mı kontrolünü yaparak, kullanılmış ise dictionaryden başka karakter seçer (Aynı karakter 1 defa kullanılmalı.)
        /// </summary>
        /// <param name="dic">Her bir harf veya rakam için kullanılabilecek karakter listesi</param>
        /// <param name="c">İlgili basamaktan önce kullanılmış karakter</param>
        /// <param name="strValue">Kod için üretilen değerlerin mevcut durumu (Kaç basamağı üretilmiş ise o kadarını tutan değer)</param>
        /// <param name="index">Karakter üretilecek basamak için inde değeri</param>
        /// <param name="count">Karakter için kullanılabilecek değerleri içeren listenin eleman sayısı</param>
        /// <returns></returns>
        private static string RandomChar(Dictionary<string, List<string>> dic, string c, string strValue, ref int index, ref int count)
        {
            List<string> lst = new List<string>();

            if (string.IsNullOrEmpty(c))
                return null;

            // İlk seçilen karakterden sonra kullanılabilecek listesine bakılır. Örneğin A için kullanılacak listeye bakılır.
            if (dic.ContainsKey(c))
            {
                dic.TryGetValue(c, out lst);
            }
            else
            {
                return null;
            }
            count = lst.Count;

            string strResult = null;
            if (lst.Count > index)
            {
                strResult = lst[index];
            }

            List<string> lstTemp = strValue.Select(s => s.ToString()).ToList();

            // Kullanılabilecek karakterler listesinden seçilen değer önceki index'ler için kullanılmış ise bir sonraki kullanılabilecek değer seçilir.
            for (int i = 0; i < strValue.Length; i++)
            {
                if (lstTemp.Contains(strResult))
                {
                    index = index + 1;

                    if (lst.Count > index)
                    {
                        strResult = lst[index];
                    }
                    else
                    {
                        strResult = lst[0];
                    }
                }
            }

            return strResult;
        }
    }
}
